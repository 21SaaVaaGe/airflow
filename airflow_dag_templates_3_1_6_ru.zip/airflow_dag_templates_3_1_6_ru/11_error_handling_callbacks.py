
from __future__ import annotations

import pendulum
from datetime import timedelta
from airflow import DAG
from airflow.decorators import task
from airflow.operators.empty import EmptyOperator

"""
11_error_handling_callbacks.py
------------------------------
Каркас обработки ошибок, который часто стандартизируют на уровне компании:
- retries, retry_delay, exponential_backoff
- callbacks: on_failure_callback / on_retry_callback / on_success_callback
- единая “обвязка” вокруг критичных задач

В примере callbacks просто печатают контекст.
В реальном мире сюда подключают Slack / Teams / Email / PagerDuty.
"""

def _on_failure(context):
    ti = context.get("ti")
    print(f"[FAIL] dag={context.get('dag').dag_id} task={ti.task_id if ti else None} run_id={context.get('run_id')}")

def _on_retry(context):
    ti = context.get("ti")
    print(f"[RETRY] dag={context.get('dag').dag_id} task={ti.task_id if ti else None} try={ti.try_number if ti else None}")

def _on_success(context):
    ti = context.get("ti")
    print(f"[OK] dag={context.get('dag').dag_id} task={ti.task_id if ti else None} run_id={context.get('run_id')}")


with DAG(
    dag_id="tpl_11_error_handling_callbacks",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="0 * * * *",
    catchup=False,
    max_active_runs=1,
    tags=["template", "callbacks"],
    default_args={
        "retries": 3,
        "retry_delay": timedelta(minutes=5),
        "retry_exponential_backoff": True,
        "max_retry_delay": timedelta(minutes=30),
        "on_failure_callback": _on_failure,
        "on_retry_callback": _on_retry,
        "on_success_callback": _on_success,
    },
) as dag:

    start = EmptyOperator(task_id="start")

    @task
    def fragile_step() -> None:
        # Замените на реальную логику. Для демонстрации можно раскомментировать исключение.
        # raise RuntimeError("boom")
        print("fragile_step ok")

    end = EmptyOperator(task_id="end")

    start >> fragile_step() >> end
