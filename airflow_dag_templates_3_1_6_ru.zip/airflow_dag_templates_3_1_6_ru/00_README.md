
# Airflow DAG templates (Apache Airflow 3.1.6) — подборка “самых используемых” шаблонов

Эта папка содержит набор практичных шаблонов DAG’ов, которые чаще всего встречаются в продакшене (ETL, SQL-пайплайны, ветвление, сенсоры, динамическое маппирование, зависимость между DAG’ами, asset-aware scheduling и т.д.).
Все примеры ориентированы на **Airflow 3.x** (используется параметр `schedule`, а не `schedule_interval`).

> Примечание по Airflow 3: `schedule_interval` удалён/устарел, используйте `schedule=...` (cron, timedelta, assets).

## Как пользоваться
1. Скопируйте нужный файл в вашу папку `dags/`.
2. Замените `conn_id`, SQL, имена таблиц/процедур и параметры расписания.
3. При необходимости настройте **Pools**, `max_active_runs`, `max_active_tasks`, retries и callbacks.
4. Убедитесь, что установлены нужные provider-пакеты (например, MSSQL / common-sql).

## Список шаблонов

### 01_taskflow_basic_etl.py
Базовый ETL на TaskFlow API: `extract -> transform -> load`. Хорош для “скелета” любого пайплайна.

### 02_mssql_stored_procs_sequential_mapped.py
MSSQL: `SELECT ...` и затем последовательный вызов нескольких **хранимых процедур** для каждого `KOM_NUMBER` через **dynamic task mapping** (валидация → дубли → insert → delete).

### 03_sql_execute_queries_operator.py
SQL-пайплайн без Python-логики: несколько SQL шагов подряд через `SQLExecuteQueryOperator` (common-sql).

### 04_branching_shortcircuit.py
Ветвление (`BranchPythonOperator`) и “короткое замыкание” (`ShortCircuitOperator`) для пропуска задач при отсутствии данных/условии.

### 05_sensors_deferrable_async.py
Сенсоры, включая **deferrable** (`DateTimeSensorAsync`) и пример `SqlSensor`. Нужен, когда вы ждёте время/данные/сигнал.

### 06_taskgroup_dynamic_mapping.py
`TaskGroup` + dynamic task mapping — удобно, когда есть N одинаковых сущностей (таблицы/клиенты/файлы).

### 07_external_task_and_trigger.py
Зависимость между DAG’ами: `ExternalTaskSensor` + `TriggerDagRunOperator` (часто применяется для оркестрации “цепочек DAG’ов”).

### 08_assets_producer.py + 09_assets_consumer.py
Asset-aware scheduling: producer обновляет asset (через `outlets=[Asset(...)]`), consumer запускается по `schedule=[Asset(...)]`.

### 10_dag_run_config_params.py
Параметры запуска (DAG params / conf), шаблонизация, типовой паттерн “один DAG — разные режимы” (full / incremental и т.п.).

### 11_error_handling_callbacks.py
Единый “каркас” обработки ошибок: callbacks, retries, единообразный логинг/алерты (в примере — заглушки).

## Рекомендации по продакшену (коротко)
- Для тяжёлых БД ограничивайте параллелизм через **Pools** и `max_active_runs=1` для DAG’ов, которые не должны накладываться.
- Для больших списков dynamic mapping — делайте батчи (TOP N / pagination) и/или фильтр “не обработано”.
- Для сенсоров в 3.x используйте deferrable, чтобы не держать воркер занятым (нужен triggerer).
