
from __future__ import annotations

import pendulum
from airflow import DAG
from airflow.decorators import task

"""
10_dag_run_config_params.py
---------------------------
Типовой паттерн: один DAG — несколько режимов запуска.
- Параметры DAG (params) со значениями по умолчанию
- Параметры DAG Run (dag_run.conf) могут переопределять поведение

Используйте, когда:
- нужен ручной “full reload”
- инкрементальные/диагностические режимы
- хочется переиспользовать один DAG для разных окружений/наборов данных
"""

with DAG(
    dag_id="tpl_10_params_and_conf",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="0 3 * * *",  # ежедневно
    catchup=False,
    tags=["template", "params"],
    params={
        "mode": "incr",         # incr | full
        "limit": 1000,
        "dry_run": False,
    },
) as dag:

    @task
    def run(**context) -> dict:
        params = context["params"]
        dag_conf = (context.get("dag_run") or {}).conf if context.get("dag_run") else {}
        mode = dag_conf.get("mode", params["mode"])
        limit = int(dag_conf.get("limit", params["limit"]))
        dry_run = bool(dag_conf.get("dry_run", params["dry_run"]))

        print(f"Run with mode={mode}, limit={limit}, dry_run={dry_run}")
        return {"mode": mode, "limit": limit, "dry_run": dry_run}

    run()
