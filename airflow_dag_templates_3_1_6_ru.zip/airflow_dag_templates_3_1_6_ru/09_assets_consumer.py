
from __future__ import annotations

import pendulum
from airflow.sdk import DAG, Asset
from airflow.decorators import task

"""
09_assets_consumer.py
---------------------
Consumer DAG: запускается, когда обновился asset (producer task завершился успешно).

Фишка:
- Airflow прокидывает triggering_asset_events (см. доки) — можно понять,
  какие именно события asset’ов вызвали запуск.
"""

example_asset = Asset("mssql://dwh/curated/kom_table")

with DAG(
    dag_id="tpl_09_assets_consumer",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule=[example_asset],  # важно: schedule принимает список asset’ов
    catchup=False,
    max_active_runs=1,
    tags=["template", "assets", "consumer"],
) as dag:

    @task
    def consume(triggering_asset_events=None) -> None:
        print("Consumer triggered by asset events:", triggering_asset_events)

    consume()
