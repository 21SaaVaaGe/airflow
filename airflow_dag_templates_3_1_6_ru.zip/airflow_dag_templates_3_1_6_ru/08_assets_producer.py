
from __future__ import annotations

import pendulum
from airflow.sdk import DAG, Asset
from airflow.decorators import task

"""
08_assets_producer.py
---------------------
Producer DAG: “обновляет asset” через outlets=[Asset(...)].
Consumer DAG запускается по этому asset (см. 09_assets_consumer.py).

Asset-aware scheduling — современная альтернатива “сенсорам между DAG’ами”.
"""

example_asset = Asset("mssql://dwh/curated/kom_table")

with DAG(
    dag_id="tpl_08_assets_producer",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="0 * * * *",
    catchup=False,
    max_active_runs=1,
    tags=["template", "assets", "producer"],
) as dag:

    @task(outlets=[example_asset])
    def produce() -> None:
        # Здесь: загрузили/обновили таблицу, сформировали витрину и т.п.
        print("Producer updated asset:", example_asset.uri)

    produce()
