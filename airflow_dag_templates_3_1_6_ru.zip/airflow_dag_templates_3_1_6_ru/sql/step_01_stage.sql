-- пример: подготовка staging
SELECT 1;
