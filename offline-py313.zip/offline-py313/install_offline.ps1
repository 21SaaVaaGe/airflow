# Офлайн-установка (запускать на машине БЕЗ интернета)
# Требуется: Python 3.13, папка wheels и constraints-3.13.txt (после download_wheels.ps1)
# Использование: .\install_offline.ps1

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

$WheelsDir = "wheels"
$ConstraintsFile = "constraints-3.13.txt"

if (-not (Test-Path $WheelsDir)) {
    Write-Host "Ошибка: папка '$WheelsDir' не найдена. Сначала выполните download_wheels.ps1 на машине с интернетом." -ForegroundColor Red
    exit 1
}
if (-not (Test-Path $ConstraintsFile)) {
    Write-Host "Ошибка: файл '$ConstraintsFile' не найден. Скопируйте его из папки offline-py313." -ForegroundColor Red
    exit 1
}

Write-Host "=== Офлайн-установка (Python 3.13) ===" -ForegroundColor Cyan
Write-Host ""

# 1. Установка Airflow с провайдерами по constraints (без выхода в интернет)
Write-Host "1. Установка Apache Airflow 3.1.6 и провайдеров..." -ForegroundColor Cyan
$airflowExtras = "apache-airflow[celery,amazon,apache.spark,apache.kafka,microsoft.mssql,postgres,redis]==3.1.6"
& pip install --no-index --find-links $WheelsDir --constraint $ConstraintsFile $airflowExtras
if ($LASTEXITCODE -ne 0) {
    Write-Host "   Ошибка установки Airflow. Проверьте наличие всех wheel в папке wheels." -ForegroundColor Red
    exit 1
}
Write-Host "   OK" -ForegroundColor Green

# 2. Установка ClickHouse и MinIO из локальных wheels
Write-Host ""
Write-Host "2. Установка clickhouse-connect, minio..." -ForegroundColor Cyan
& pip install --no-index --find-links $WheelsDir clickhouse-connect minio
if ($LASTEXITCODE -ne 0) { Write-Host "   Предупреждение: установка части пакетов не удалась." -ForegroundColor Yellow }
else { Write-Host "   OK" -ForegroundColor Green }

Write-Host ""
Write-Host "Установка завершена." -ForegroundColor Green
Write-Host "Проверка: airflow version" -ForegroundColor Gray
& airflow version
