# Скачивание всех wheel/sdist для офлайн-установки (запускать на машине С интернетом)
# Требуется: Python 3.13, pip
# Использование: .\download_wheels.ps1

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

$WheelsDir = "wheels"
$ConstraintsUrl = "https://raw.githubusercontent.com/apache/airflow/constraints-3.1.6/constraints-3.13.txt"
$ConstraintsFile = "constraints-3.13.txt"
$RequirementsFile = "requirements-offline-py313.txt"

Write-Host "=== Офлайн-пакеты для Python 3.13 ===" -ForegroundColor Cyan
Write-Host "Airflow 3.1.6 + ClickHouse, Spark, MSSQL, Postgres, MinIO, RabbitMQ, Kafka, Redis, SQLAlchemy" -ForegroundColor Gray
Write-Host ""

# Проверка Python
$pyVer = python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Ошибка: Python не найден. Установите Python 3.13." -ForegroundColor Red
    exit 1
}
Write-Host "Python: $pyVer" -ForegroundColor Green
if ($pyVer -notmatch "^3\.13") {
    Write-Host "Предупреждение: для Airflow 3.1.6 рекомендуется Python 3.13." -ForegroundColor Yellow
}

New-Item -ItemType Directory -Force -Path $WheelsDir | Out-Null
Write-Host "Папка wheels: $ScriptDir\$WheelsDir" -ForegroundColor Green

# 1. Скачивание constraints Airflow
Write-Host ""
Write-Host "1. Скачивание constraints Airflow 3.1.6 (Python 3.13)..." -ForegroundColor Cyan
try {
    Invoke-WebRequest -Uri $ConstraintsUrl -OutFile $ConstraintsFile -UseBasicParsing
    Write-Host "   OK: $ConstraintsFile" -ForegroundColor Green
} catch {
    Write-Host "   Ошибка: $_" -ForegroundColor Red
    exit 1
}

# 2. Скачивание Airflow и всех зависимостей по constraints
Write-Host ""
Write-Host "2. Скачивание Apache Airflow 3.1.6 и провайдеров (с constraints)..." -ForegroundColor Cyan
$airflowExtras = "apache-airflow[celery,amazon,apache.spark,apache.kafka,microsoft.mssql,postgres,redis]==3.1.6"
& pip download --constraint $ConstraintsFile --dest $WheelsDir $airflowExtras
if ($LASTEXITCODE -ne 0) {
    Write-Host "   Ошибка при скачивании Airflow." -ForegroundColor Red
    exit 1
}
Write-Host "   OK" -ForegroundColor Green

# 3. Дополнительные пакеты (ClickHouse, MinIO) — не в constraints
Write-Host ""
Write-Host "3. Скачивание clickhouse-connect, minio и зависимостей..." -ForegroundColor Cyan
& pip download --dest $WheelsDir clickhouse-connect minio
if ($LASTEXITCODE -ne 0) { Write-Host "   Предупреждение: не все пакеты скачаны." -ForegroundColor Yellow }
else { Write-Host "   OK" -ForegroundColor Green }

# 4. Итог
$count = (Get-ChildItem $WheelsDir -File -Filter "*.whl").Count
$count += (Get-ChildItem $WheelsDir -File -Filter "*.tar.gz").Count
Write-Host ""
Write-Host "Готово. Скачано пакетов: $count" -ForegroundColor Green
Write-Host ""
Write-Host "Дальше:" -ForegroundColor Cyan
Write-Host "  1. Перенесите папку 'offline-py313' (вместе с wheels и constraints-3.13.txt) на машину БЕЗ интернета."
Write-Host "  2. На целевой машине выполните: .\install_offline.ps1"
Write-Host ""
