
from __future__ import annotations

import pendulum
from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import BranchPythonOperator, ShortCircuitOperator
from airflow.decorators import task

"""
04_branching_shortcircuit.py
----------------------------
Два самых частых “управляющих” паттерна:
1) BranchPythonOperator — выбирает ветку выполнения (одна/несколько задач).
2) ShortCircuitOperator — если условие False, “гасит” downstream задачи.

Используйте:
- Branch: разные пути обработки (full vs incremental, типы данных, разные источники)
- ShortCircuit: когда данных нет/условие не выполнено -> не тратить ресурсы
"""

with DAG(
    dag_id="tpl_04_branching_shortcircuit",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="*/15 * * * *",  # каждые 15 минут
    catchup=False,
    tags=["template", "branching"],
) as dag:

    start = EmptyOperator(task_id="start")

    @task
    def has_data() -> bool:
        # Замените на реальную проверку (SELECT COUNT(*), наличие файла и т.п.)
        return True

    gate = ShortCircuitOperator(
        task_id="gate_has_data",
        python_callable=lambda: True,  # проще, но можно использовать XCom от has_data
    )

    def choose_path(**context) -> str:
        # Пример: выбор ветки по дню недели
        now = pendulum.now("UTC")
        return "full_load" if now.day_of_week == pendulum.MONDAY else "incremental_load"

    branch = BranchPythonOperator(
        task_id="branch_full_vs_incr",
        python_callable=choose_path,
    )

    full_load = EmptyOperator(task_id="full_load")
    incremental_load = EmptyOperator(task_id="incremental_load")

    end = EmptyOperator(task_id="end", trigger_rule="none_failed_min_one_success")

    start >> has_data() >> gate >> branch
    branch >> [full_load, incremental_load] >> end
