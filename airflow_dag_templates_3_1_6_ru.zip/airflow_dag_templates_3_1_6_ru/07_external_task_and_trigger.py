
from __future__ import annotations

import pendulum
from datetime import timedelta

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.sensors.external_task import ExternalTaskSensor
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

"""
07_external_task_and_trigger.py
-------------------------------
Два популярных способа связать DAG'и:
1) ExternalTaskSensor — ждать, пока в другом DAG завершится задача/запуск
2) TriggerDagRunOperator — явно триггерить другой DAG (push-оркестрация)

Важно:
- ExternalTaskSensor удобен, но может быть “хрупким” при backfill/catchup,
  особенно если вы жёстко привязываетесь к execution_date/data_interval.
- Для сложных зависимостей и data-driven лучше рассмотреть assets.
"""

UPSTREAM_DAG_ID = "some_upstream_dag"
UPSTREAM_TASK_ID = "finalize"   # задача в upstream DAG, которую ждём
DOWNSTREAM_DAG_ID = "some_downstream_dag"

with DAG(
    dag_id="tpl_07_external_task_and_trigger",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="0 * * * *",
    catchup=False,
    max_active_runs=1,
    tags=["template", "external", "trigger"],
    default_args={"retries": 2, "retry_delay": timedelta(minutes=5)},
) as dag:

    start = EmptyOperator(task_id="start")

    wait_upstream = ExternalTaskSensor(
        task_id="wait_upstream_finalize",
        external_dag_id=UPSTREAM_DAG_ID,
        external_task_id=UPSTREAM_TASK_ID,
        allowed_states=["success"],
        failed_states=["failed", "skipped"],
        timeout=60 * 60,
        poke_interval=60,
        mode="reschedule",
    )

    trigger_downstream = TriggerDagRunOperator(
        task_id="trigger_downstream_dag",
        trigger_dag_id=DOWNSTREAM_DAG_ID,
        conf={"source": "tpl_07", "run_mode": "auto"},
        wait_for_completion=False,
    )

    end = EmptyOperator(task_id="end")

    start >> wait_upstream >> trigger_downstream >> end
