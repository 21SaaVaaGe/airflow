
from __future__ import annotations

import pendulum
from datetime import timedelta

from airflow import DAG
from airflow.decorators import task
from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook

"""
02_mssql_stored_procs_sequential_mapped.py
------------------------------------------
Шаблон под MSSQL: берём список KOM_NUMBER из SELECT,
а затем для каждого KOM_NUMBER последовательно вызываем процедуры:
validate -> dedup -> insert -> delete.

Плюсы:
- “естественная” последовательность шагов для одной сущности
- горизонтальное масштабирование на много KOM_NUMBER через dynamic task mapping

Практика:
- ограничивайте параллелизм, чтобы не перегрузить MSSQL (max_active_tasks / pools)
- делайте SELECT только по “необработанным” записям
"""

DAG_ID = "tpl_02_mssql_procs_mapped"
MSSQL_CONN_ID = "mssql_default"  # замените на ваш conn_id

KOM_SELECT_SQL = """
SELECT KOM_NUMBER, KOM_DATE
FROM dbo.KOM_SOURCE
-- WHERE IsProcessed = 0
ORDER BY KOM_DATE
"""

PROC_VALIDATE = "dbo.usp_kom_validate"
PROC_DEDUP    = "dbo.usp_kom_find_duplicates"
PROC_INSERT   = "dbo.usp_kom_insert"
PROC_DELETE   = "dbo.usp_kom_delete"


def _call_proc(proc_name: str, kom_number: str) -> None:
    hook = MsSqlHook(mssql_conn_id=MSSQL_CONN_ID)
    conn = hook.get_conn()
    try:
        hook.set_autocommit(conn, True)
        cur = conn.cursor()
        try:
            cur.callproc(proc_name, (kom_number,))
        finally:
            cur.close()
    finally:
        conn.close()


with DAG(
    dag_id=DAG_ID,
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="0 * * * *",  # каждый час
    catchup=False,
    max_active_runs=1,          # “каждый час или пока не завершится”: без перекрытий
    dagrun_timeout=timedelta(hours=12),
    max_active_tasks=16,        # общий параллелизм по задачам в DAG
    tags=["template", "mssql", "stored-proc", "mapping"],
    default_args={"retries": 3, "retry_delay": timedelta(minutes=5)},
) as dag:

    @task
    def fetch_kom_records() -> list[dict]:
        hook = MsSqlHook(mssql_conn_id=MSSQL_CONN_ID)
        rows = hook.get_records(KOM_SELECT_SQL)
        return [{"kom_number": str(n), "kom_date": str(d)} for n, d in rows]

    @task
    def validate(record: dict) -> dict:
        _call_proc(PROC_VALIDATE, record["kom_number"])
        return record

    @task
    def dedup(record: dict) -> dict:
        _call_proc(PROC_DEDUP, record["kom_number"])
        return record

    @task
    def do_insert(record: dict) -> dict:
        _call_proc(PROC_INSERT, record["kom_number"])
        return record

    @task
    def do_delete(record: dict) -> dict:
        _call_proc(PROC_DELETE, record["kom_number"])
        return record

    records = fetch_kom_records()

    v = validate.expand(record=records)
    d = dedup.expand(record=v)
    i = do_insert.expand(record=d)
    do_delete.expand(record=i)
