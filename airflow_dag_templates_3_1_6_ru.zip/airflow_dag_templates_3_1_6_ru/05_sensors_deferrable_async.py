
from __future__ import annotations

import pendulum
from datetime import timedelta

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.providers.common.sql.sensors.sql import SqlSensor
from airflow.sensors.date_time import DateTimeSensorAsync

"""
05_sensors_deferrable_async.py
------------------------------
Сенсоры — классика Airflow:
- ждать “появления данных” (например, запись в таблице)
- ждать времени
- ждать внешнего состояния

В Airflow 3.x рекомендуется использовать deferrable/async сенсоры, чтобы не держать воркер занятым.
Для deferrable нужен запущенный triggerer.

Здесь:
1) DateTimeSensorAsync (deferrable) — ждём конкретного времени
2) SqlSensor — ждём, пока запрос вернёт условие/строку
"""

CONN_ID = "mssql_default"

with DAG(
    dag_id="tpl_05_sensors_deferrable",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="0 * * * *",
    catchup=False,
    max_active_runs=1,
    tags=["template", "sensors", "deferrable"],
    default_args={"retries": 2, "retry_delay": timedelta(minutes=5)},
) as dag:

    start = EmptyOperator(task_id="start")

    # Ждём, например, до HH:10 каждого часа (демо)
    wait_until = DateTimeSensorAsync(
        task_id="wait_until_hh10",
        target_time="{{ (data_interval_start + macros.timedelta(minutes=10)) }}",
        poke_interval=30,
        timeout=60 * 30,
    )

    # Ждём появления “признака готовности” в БД
    wait_for_data = SqlSensor(
        task_id="wait_for_ready_row",
        conn_id=CONN_ID,
        sql="""
        SELECT 1
        WHERE EXISTS (
            SELECT 1
            FROM dbo.ReadyFlag
            WHERE flag = 1
        )
        """,
        poke_interval=60,
        timeout=60 * 30,
        mode="reschedule",  # для обычного сенсора; deferrable — отдельные классы
    )

    end = EmptyOperator(task_id="end")

    start >> wait_until >> wait_for_data >> end
