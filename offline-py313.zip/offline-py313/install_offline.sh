#!/usr/bin/env bash
# Офлайн-установка (машина БЕЗ интернета, Linux/macOS)
# Требуется: Python 3.13, папка wheels и constraints-3.13.txt
# Использование: chmod +x install_offline.sh && ./install_offline.sh

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

WHEELS_DIR="wheels"
CONSTRAINTS_FILE="constraints-3.13.txt"

if [ ! -d "$WHEELS_DIR" ]; then
  echo "Ошибка: папка '$WHEELS_DIR' не найдена. Сначала выполните download_wheels.sh на машине с интернетом."
  exit 1
fi
if [ ! -f "$CONSTRAINTS_FILE" ]; then
  echo "Ошибка: файл '$CONSTRAINTS_FILE' не найден."
  exit 1
fi

echo "=== Офлайн-установка (Python 3.13) ==="
echo ""

echo "1. Установка Apache Airflow 3.1.6 и провайдеров..."
pip install --no-index --find-links "$WHEELS_DIR" --constraint "$CONSTRAINTS_FILE" \
  "apache-airflow[celery,amazon,apache.spark,apache.kafka,microsoft.mssql,postgres,redis]==3.1.6" || exit 1
echo "   OK"
echo ""

echo "2. Установка clickhouse-connect, minio..."
pip install --no-index --find-links "$WHEELS_DIR" clickhouse-connect minio || echo "   Предупреждение: установка части пакетов не удалась."
echo "   OK"
echo ""

echo "Установка завершена."
echo "Проверка: airflow version"
airflow version
