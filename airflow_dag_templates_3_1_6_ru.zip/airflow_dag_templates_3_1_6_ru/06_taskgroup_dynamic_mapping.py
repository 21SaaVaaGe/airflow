
from __future__ import annotations

import pendulum
from airflow import DAG
from airflow.decorators import task
from airflow.utils.task_group import TaskGroup
from airflow.operators.empty import EmptyOperator

"""
06_taskgroup_dynamic_mapping.py
-------------------------------
TaskGroup + dynamic task mapping:
Типовой кейс: есть список сущностей (таблицы/клиенты/файлы) и нужно
выполнить одинаковый набор шагов на каждую сущность, сохраняя читабельный граф.

Шаблон удобен, когда:
- операций несколько, хочется “свернуть” их в группу
- сущностей много и они меняются во времени
"""

with DAG(
    dag_id="tpl_06_taskgroup_dynamic_mapping",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="0 */6 * * *",  # каждые 6 часов
    catchup=False,
    tags=["template", "taskgroup", "mapping"],
) as dag:

    start = EmptyOperator(task_id="start")

    @task
    def list_entities() -> list[dict]:
        # Пример: список таблиц/клиентов/файлов
        return [
            {"entity": "A", "mode": "incr"},
            {"entity": "B", "mode": "full"},
            {"entity": "C", "mode": "incr"},
        ]

    @task
    def extract_one(entity: dict) -> dict:
        # Достаньте данные/метаданные для entity
        return {**entity, "rows": 123}

    @task
    def process_one(entity: dict) -> dict:
        # Трансформация
        return {**entity, "processed": True}

    @task
    def load_one(entity: dict) -> None:
        # Загрузка результата
        print(f"Loaded entity={entity['entity']} mode={entity['mode']} rows={entity.get('rows')}")

    with TaskGroup(group_id="per_entity") as per_entity:
        entities = list_entities()
        e = extract_one.expand(entity=entities)
        p = process_one.expand(entity=e)
        load_one.expand(entity=p)

    end = EmptyOperator(task_id="end")

    start >> per_entity >> end
