#!/usr/bin/env bash
# Скачивание всех wheel/sdist для офлайн-установки (машина С интернетом, Linux/macOS)
# Требуется: Python 3.13, pip
# Использование: chmod +x download_wheels.sh && ./download_wheels.sh

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

WHEELS_DIR="wheels"
CONSTRAINTS_URL="https://raw.githubusercontent.com/apache/airflow/constraints-3.1.6/constraints-3.13.txt"
CONSTRAINTS_FILE="constraints-3.13.txt"

echo "=== Офлайн-пакеты для Python 3.13 ==="
echo "Airflow 3.1.6 + ClickHouse, Spark, MSSQL, Postgres, MinIO, RabbitMQ, Kafka, Redis, SQLAlchemy"
echo ""

py_ver=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null || true)
if [ -z "$py_ver" ]; then
  echo "Ошибка: Python не найден. Установите Python 3.13."
  exit 1
fi
echo "Python: $py_ver"

mkdir -p "$WHEELS_DIR"
echo "Папка wheels: $SCRIPT_DIR/$WHEELS_DIR"
echo ""

echo "1. Скачивание constraints Airflow 3.1.6 (Python 3.13)..."
curl -sSL -o "$CONSTRAINTS_FILE" "$CONSTRAINTS_URL" || { echo "Ошибка скачивания constraints"; exit 1; }
echo "   OK: $CONSTRAINTS_FILE"
echo ""

echo "2. Скачивание Apache Airflow 3.1.6 и провайдеров (с constraints)..."
pip download --constraint "$CONSTRAINTS_FILE" --dest "$WHEELS_DIR" \
  "apache-airflow[celery,amazon,apache.spark,apache.kafka,microsoft.mssql,postgres,redis]==3.1.6" || exit 1
echo "   OK"
echo ""

echo "3. Скачивание clickhouse-connect, minio и зависимостей..."
pip download --dest "$WHEELS_DIR" clickhouse-connect minio || echo "   Предупреждение: не все пакеты скачаны."
echo "   OK"
echo ""

count_whl=$(find "$WHEELS_DIR" -maxdepth 1 -name "*.whl" 2>/dev/null | wc -l)
count_tar=$(find "$WHEELS_DIR" -maxdepth 1 -name "*.tar.gz" 2>/dev/null | wc -l)
echo "Готово. Скачано пакетов: $((count_whl + count_tar))"
echo ""
echo "Дальше:"
echo "  1. Перенесите папку 'offline-py313' (вместе с wheels и $CONSTRAINTS_FILE) на машину БЕЗ интернета."
echo "  2. На целевой машине выполните: ./install_offline.sh"
echo ""
