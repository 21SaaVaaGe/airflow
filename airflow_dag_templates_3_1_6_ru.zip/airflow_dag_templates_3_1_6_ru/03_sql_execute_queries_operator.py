
from __future__ import annotations

import pendulum
from airflow import DAG
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.operators.empty import EmptyOperator

"""
03_sql_execute_queries_operator.py
----------------------------------
Частый продакшен-паттерн: “чистый SQL-пайплайн” без Python-логики.
Подходит для DWH / витрин / staging-слоёв, когда вся логика в SQL/процедурах.

Использует common-sql operator `SQLExecuteQueryOperator`.
Для MSSQL должен быть корректно настроен conn_id и provider.
"""

CONN_ID = "mssql_default"  # для MSSQL

with DAG(
    dag_id="tpl_03_sql_execute_queries",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="0 2 * * *",  # ежедневно в 02:00 UTC
    catchup=False,
    max_active_runs=1,
    tags=["template", "sql", "common-sql"],
) as dag:

    start = EmptyOperator(task_id="start")

    step_01_stage = SQLExecuteQueryOperator(
        task_id="step_01_stage",
        conn_id=CONN_ID,
        sql="sql/step_01_stage.sql",  # можно путь к файлу, если в dags_folder есть подкаталог sql/
    )

    step_02_transform = SQLExecuteQueryOperator(
        task_id="step_02_transform",
        conn_id=CONN_ID,
        sql="sql/step_02_transform.sql",
    )

    step_03_publish = SQLExecuteQueryOperator(
        task_id="step_03_publish",
        conn_id=CONN_ID,
        sql="sql/step_03_publish.sql",
    )

    end = EmptyOperator(task_id="end")

    start >> step_01_stage >> step_02_transform >> step_03_publish >> end
