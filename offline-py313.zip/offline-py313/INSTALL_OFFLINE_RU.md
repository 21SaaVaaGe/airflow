# Офлайн-установка: Python 3.13, Airflow 3.1.6 и стек (ClickHouse, Spark, MSSQL, Postgres, MinIO, RabbitMQ, Kafka, Redis, SQLAlchemy)

Установка **без интернета** на целевую машину: все пакеты скачиваются один раз на машине с доступом в интернет, затем переносятся и ставятся локально.

---

## Что входит в набор

| Компонент | Пакеты / провайдеры Airflow |
|-----------|-----------------------------|
| **Apache Airflow** | `apache-airflow==3.1.6` |
| **PostgreSQL** | `apache-airflow-providers-postgres`, `psycopg2-binary` |
| **MSSQL** | `apache-airflow-providers-microsoft-mssql`, `pymssql` |
| **Redis** | `apache-airflow-providers-redis`, `redis` |
| **RabbitMQ** | `apache-airflow-providers-celery` (Celery + AMQP) |
| **Kafka** | `apache-airflow-providers-apache-kafka` |
| **Spark** | `apache-airflow-providers-apache-spark`, `pyspark` |
| **MinIO (S3)** | `apache-airflow-providers-amazon` (S3-совместимый endpoint), клиент `minio` |
| **ClickHouse** | клиент `clickhouse-connect` (в Airflow — через Connection + свой код или BaseSQL) |
| **SQLAlchemy** | входит в Airflow; при необходимости можно добавить в requirements |

---

## Требования

- **Python 3.13** на обеих машинах (на той, где качаете, и на той, где ставите офлайн).
- **pip** обновлён: `python -m pip install --upgrade pip`
- На машине **с интернетом**: PowerShell (Windows) или bash (Linux/macOS) для скриптов `download_wheels.ps1` / `download_wheels.sh`.

---

## Шаг 1. Скачивание пакетов (машина С интернетом)

1. Установите **Python 3.13** и убедитесь, что в консоли используется он:
   ```powershell
   python --version
   # Должно быть: Python 3.13.x
   ```

2. Перейдите в папку с файлами офлайн-установки:
   ```powershell
   cd путь\к\offline-py313
   ```

3. Запустите скрипт скачивания:
   - **Windows (PowerShell):** `.\download_wheels.ps1`
   - **Linux/macOS:** `chmod +x download_wheels.sh && ./download_wheels.sh`
   Скрипт:
   - скачает файл ограничений Airflow `constraints-3.13.txt`;
   - скачает Apache Airflow 3.1.6 с провайдерами (celery, amazon, apache.spark, apache.kafka, microsoft.mssql, postgres, redis) и все их зависимости в папку `wheels`;
   - скачает `clickhouse-connect` и `minio` и их зависимости в ту же папку `wheels`.

4. Убедитесь, что появились:
   - папка **`wheels`** с множеством файлов `.whl` (и при необходимости `.tar.gz`);
   - файл **`constraints-3.13.txt`** в корне `offline-py313`.

---

## Шаг 2. Перенос на машину БЕЗ интернета

Скопируйте **целиком** папку **`offline-py313`** на целевую машину (флешка, внутренняя сеть, другой диск и т.п.), чтобы на ней были:

- папка **`wheels`** со всеми скачанными файлами;
- файл **`constraints-3.13.txt`**;
- файл **`install_offline.ps1`**;
- при желании — **`requirements-offline-py313.txt`** и **`INSTALL_OFFLINE_RU.md`**.

На целевой машине должен быть установлен **Python 3.13** (той же разрядности, что и при скачивании: 64-bit с 64-bit).

---

## Шаг 3. Установка на машине БЕЗ интернета

1. Откройте PowerShell и перейдите в скопированную папку:
   ```powershell
   cd путь\к\offline-py313
   ```

2. Запустите офлайн-установку:
   - **Windows (PowerShell):** `.\install_offline.ps1`
   - **Linux/macOS:** `chmod +x install_offline.sh && ./install_offline.sh`
   Скрипт:
   - установит Apache Airflow 3.1.6 и указанные провайдеры из папки `wheels` с учётом `constraints-3.13.txt`;
   - установит `clickhouse-connect` и `minio` из той же папки `wheels`.

3. Проверка:
   ```powershell
   airflow version
   python -c "import clickhouse_connect; import minio; print('OK')"
   ```

---

## Ручная установка (если скрипты не подходят)

### На машине С интернетом (скачать)

```powershell
# 1. Скачать constraints
Invoke-WebRequest -Uri "https://raw.githubusercontent.com/apache/airflow/constraints-3.1.6/constraints-3.13.txt" -OutFile constraints-3.13.txt

# 2. Скачать Airflow и провайдеры
pip download --constraint constraints-3.13.txt --dest wheels "apache-airflow[celery,amazon,apache.spark,apache.kafka,microsoft.mssql,postgres,redis]==3.1.6"

# 3. Скачать ClickHouse и MinIO
pip download --dest wheels clickhouse-connect minio
```

### На машине БЕЗ интернета (установить)

```powershell
# 1. Airflow с провайдерами
pip install --no-index --find-links wheels --constraint constraints-3.13.txt "apache-airflow[celery,amazon,apache.spark,apache.kafka,microsoft.mssql,postgres,redis]==3.1.6"

# 2. ClickHouse и MinIO
pip install --no-index --find-links wheels clickhouse-connect minio
```

---

## Виртуальное окружение (рекомендуется)

На целевой машине лучше ставить в отдельное окружение:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
# затем запуск install_offline.ps1 или команды pip из раздела выше
```

---

## Возможные проблемы

1. **Ошибка при скачивании** — проверьте интернет и доступ к PyPI; при блокировках можно задать `pip` зеркало или прокси.
2. **Разная ОС/архитектура** — wheels собираются под платформу. Если скачивали на Windows, а ставите на Linux (или наоборот), нужно на машине с интернетом указать целевую платформу, например:
   ```powershell
   $env:PIP_PLATFORM = "manylinux2014_x86_64"   # для Linux x64
   .\download_wheels.ps1
   ```
3. **Нет какого-то wheel** — убедитесь, что скрипт скачивания отработал до конца и папка `wheels` не была обрезана при копировании.
4. **MSSQL под Windows** — при необходимости добавьте в `requirements-offline-py313.txt` пакет `pyodbc` и заново выполните шаг скачивания и переноса.

---

## Файлы в папке offline-py313

| Файл / папка | Назначение |
|--------------|------------|
| `requirements-offline-py313.txt` | Список пакетов для справки и ручной установки |
| `download_wheels.ps1` | Скрипт скачивания (машина с интернетом) |
| `install_offline.ps1` / `install_offline.sh` | Скрипт офлайн-установки (машина без интернета) |
| `download_wheels.sh` | Скачивание wheels на Linux/macOS (машина с интернетом) |
| `constraints-3.13.txt` | Ограничения версий Airflow (скачивается скриптом) |
| `wheels/` | Каталог со всеми скачанными пакетами |
| `INSTALL_OFFLINE_RU.md` | Эта инструкция |

После выполнения шагов 1–3 у вас будет рабочая среда: Python 3.13, Airflow 3.1.6 и провайдеры для ClickHouse, Spark, MSSQL, Postgres, MinIO, RabbitMQ (Celery), Kafka, Redis и SQLAlchemy, установленные вручную без интернета на целевой машине.
