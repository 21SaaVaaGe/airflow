
from __future__ import annotations

import pendulum
from airflow import DAG
from airflow.decorators import task
from airflow.operators.empty import EmptyOperator

"""
01_taskflow_basic_etl.py
------------------------
Самый частый каркас: extract -> transform -> load (TaskFlow API).

Что важно для Airflow 3.x:
- Используйте параметр DAG `schedule=...` (cron/timedelta/asset), а не schedule_interval.
- Явно задавайте start_date с таймзоной (pendulum).
"""

with DAG(
    dag_id="tpl_01_taskflow_basic_etl",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    schedule="0 * * * *",  # каждый час
    catchup=False,
    max_active_runs=1,      # не накладывать запуски
    tags=["template", "taskflow", "etl"],
) as dag:

    start = EmptyOperator(task_id="start")

    @task
    def extract() -> list[dict]:
        # Здесь обычно: чтение из БД / API / файлового хранилища
        # Возвращаем небольшой набор “сырья” в XCom (для больших объёмов лучше внешнее хранилище)
        return [{"id": 1, "value": "10"}, {"id": 2, "value": "20"}]

    @task
    def transform(rows: list[dict]) -> list[dict]:
        # Пример трансформации
        out = []
        for r in rows:
            out.append({"id": r["id"], "value": int(r["value"]) * 2})
        return out

    @task
    def load(rows: list[dict]) -> int:
        # Здесь обычно: запись в БД (upsert), отправка в очередь и т.д.
        # Возвращаем метрику/статистику
        return len(rows)

    end = EmptyOperator(task_id="end")

    start >> load(transform(extract())) >> end
